plot(svd1$v[,2],pch=19,col=rgb(0,0,0,.5))
par(mfrow = c(1, 1))