library(datasets)
# Put initialization code in this file.
path_to_course <- file.path(find.package("swirl"),"Courses/Exploratory_Data_Analysis/Graphics_Devices_in_R")

try(dev.off(),silent=TRUE)
plot.new()

