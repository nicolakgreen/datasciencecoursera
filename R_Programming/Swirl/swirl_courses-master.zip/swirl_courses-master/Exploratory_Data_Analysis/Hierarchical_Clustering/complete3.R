segments(x[4],y[4],x[11],y[11],lwd=3,col="orange")
