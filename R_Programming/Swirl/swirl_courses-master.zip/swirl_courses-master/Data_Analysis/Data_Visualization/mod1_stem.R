# Stem and leaf plot
cat("\n")
stem(cars$mpgCity)