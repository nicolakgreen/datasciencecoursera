# Handles time info with ymd_hms()
dt1 <- '2014-08-23 17:23:02'

# Also handles vectors of date-times
dt2 <- c('2014-05-14', '2014-09-22', '2014-07-11')

# For last unit of the lesson
stopwatch <- function() {
  invisible()
}
